import 'package:flutter/material.dart';
import 'dart:math';

void main() {
  runApp(ScientificCalculator());
}

class ScientificCalculator extends StatelessWidget {
  const ScientificCalculator({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CalculatorScreen(),
    );
  }
}

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _CalculatorScreenState createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _expression = "";

  void _onPressed(String value) {
    setState(() {
      if (value == "C") {
        _expression = "";
      } else if (value == "=") {
        try {
          _expression = _evaluateExpression(_expression);
        } catch (e) {
          _expression = "Erro";
        }
      } else {
        _expression += value;
      }
    });
  }

  String _evaluateExpression(String exp) {
    try {
      exp = exp.replaceAll("√", "sqrt");
      exp = exp.replaceAll("π", pi.toString());
      exp = exp.replaceAll("e", e.toString());
      
      double result = _calculate(exp);
      return result.toString();
    } catch (e) {
      return "Erro";
    }
  }

  double _calculate(String exp) {
    try {
      return double.parse(exp);
    } catch (e) {
      return 0;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Calculadora Científica")),
      body: Column(
        children: [
          Expanded(
            child: Container(
              padding: EdgeInsets.all(16),
              alignment: Alignment.centerRight,
              child: Text(
                _expression,
                style: TextStyle(fontSize: 32),
              ),
            ),
          ),
          GridView.count(
            shrinkWrap: true,
            crossAxisCount: 4,
            children: [
              "7", "8", "9", "/",
              "4", "5", "6", "*",
              "1", "2", "3", "-",
              "0", ".", "=", "+",
              "C", "√", "π", "e"
            ].map((label) {
              return ElevatedButton(
                onPressed: () => _onPressed(label),
                child: Text(label, style: TextStyle(fontSize: 24)),
              );
            }).toList(),
          )
        ],
      ),
    );
  }
}
